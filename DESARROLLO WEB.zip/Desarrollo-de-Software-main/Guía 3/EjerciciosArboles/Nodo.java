class Nodo {
    int dato;
    Nodo izquierdo;
    Nodo derecho;

    Nodo(int dato) {
        this.dato = dato;
        izquierdo = derecho = null;
    }
}